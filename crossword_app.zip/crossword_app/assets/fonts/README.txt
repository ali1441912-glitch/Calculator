ضع هنا ملف خط عربي باسم arabic.ttf يدعم اللغة العربية بشكل جيد
مثل: Noto Naskh Arabic أو Amiri أو Cairo.
بدون هذا الملف قد لا تظهر الحروف العربية متصلة بشكل صحيح داخل التطبيق.
يمكن تحميل خط مجاني من Google Fonts (fonts.google.com) وإعادة تسميته إلى arabic.ttf
