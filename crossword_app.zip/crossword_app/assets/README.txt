ضع هنا أيقونة icon.png (512x512) وصورة بداية presplash.png للتطبيق
