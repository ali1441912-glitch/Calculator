# -*- coding: utf-8 -*-
"""
لعبة الكلمات المتقاطعة - تطبيق أندرويد
====================================
تطبيق كلاسيكي بطابع صحف الجرائد: شبكة بيضاء/سوداء، أرقام في زوايا الخانات،
قوائم أدلة أفقية وعمودية، ولوحة مفاتيح عربية للإدخال.
- توليد ألغاز عشوائية بلا نهاية من بنك ثقافة عامة (word_bank.py).
- حفظ تلقائي للتقدم عند كل إدخال وعند إغلاق/تعليق التطبيق.
- عند إكمال لغز بنجاح تبدأ اللعبة تلقائياً بلغز جديد.
"""

import random

from kivy.app import App
from kivy.clock import Clock
from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.button import Button
from kivy.graphics import Color, Rectangle

from arabic_utils import ar, normalize_char
from crossword_generator import CrosswordGenerator, Puzzle
from storage import ProgressStore

# ------------------------------------------------------------------ #
# محاولة تسجيل خط عربي مرفق مع التطبيق (ضعه في assets/fonts/arabic.ttf)
# في حال عدم توفره سيستخدم Kivy الخط الافتراضي (قد لا يدعم العربية جيداً).
try:
    LabelBase.register(name="Arabic", fn_regular="assets/fonts/arabic.ttf")
    FONT_NAME = "Arabic"
except Exception:
    FONT_NAME = None

# ألوان بطابع الجرائد الكلاسيكي
COLOR_PAPER = (0.96, 0.94, 0.88, 1)      # خلفية بلون الورق الكريمي
COLOR_BLACK_CELL = (0.08, 0.08, 0.08, 1)
COLOR_WHITE_CELL = (1, 1, 1, 1)
COLOR_SELECTED_WORD = (1, 0.92, 0.55, 1)
COLOR_SELECTED_CELL = (1, 0.72, 0.25, 1)
COLOR_CORRECT_FLASH = (0.72, 0.9, 0.6, 1)
COLOR_INK = (0.1, 0.1, 0.1, 1)


def L(text, **kwargs):
    """تسمية جاهزة بخط عربي مُشكّل ومحاذاة صحيحة."""
    kwargs.setdefault("color", COLOR_INK)
    if FONT_NAME:
        kwargs.setdefault("font_name", FONT_NAME)
    return Label(text=ar(text), **kwargs)


class GridCell(ButtonBehavior, Label):
    """خانة واحدة في شبكة الكلمات المتقاطعة."""

    def __init__(self, coord, blocked=False, number=None, **kwargs):
        super().__init__(**kwargs)
        self.coord = coord
        self.blocked = blocked
        self.number = number
        self.user_letter = ""
        self.bold = True
        if FONT_NAME:
            self.font_name = FONT_NAME
        self.font_size = kwargs.get("font_size", dp(18))
        self.number_label = None
        with self.canvas.before:
            self.bg_color = Color(*self._base_color())
            self.bg_rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._update_rect, size=self._update_rect)
        self.set_letter("")

    def _base_color(self):
        return COLOR_BLACK_CELL if self.blocked else COLOR_WHITE_CELL

    def _update_rect(self, *_):
        self.bg_rect.pos = self.pos
        self.bg_rect.size = self.size

    def set_highlight(self, color):
        self.bg_color.rgba = color

    def reset_highlight(self):
        self.bg_color.rgba = self._base_color()

    def set_letter(self, letter):
        self.user_letter = letter
        self.text = "" if self.blocked else letter


class CrosswordGridWidget(GridLayout):
    """يبني شبكة الخانات ويعرضها بشكل مرآوي (يمين إلى يسار) كالصحف العربية."""

    def __init__(self, controller, **kwargs):
        super().__init__(**kwargs)
        self.controller = controller
        self.cells = {}

    def build(self, puzzle: Puzzle):
        self.clear_widgets()
        self.cells = {}
        self.cols = puzzle.width
        self.rows = puzzle.height
        cell_size = dp(26)
        self.size_hint = (None, None)
        self.width = cell_size * puzzle.width
        self.height = cell_size * puzzle.height

        for r in range(puzzle.height):
            # نعكس ترتيب الأعمدة بصرياً حتى تُقرأ الكلمات الأفقية من اليمين لليسار
            for c in range(puzzle.width - 1, -1, -1):
                is_open = puzzle.is_open(r, c)
                number = puzzle.numbering.get((r, c))
                cell = GridCell(
                    coord=(r, c),
                    blocked=not is_open,
                    number=number,
                    size_hint=(None, None),
                    size=(cell_size, cell_size),
                )
                if is_open:
                    cell.bind(on_release=self._make_on_press(r, c))
                self.add_widget(cell)
                self.cells[(r, c)] = cell
                if number and is_open:
                    self._add_number_badge(cell, number, cell_size)

    def _add_number_badge(self, cell, number, cell_size):
        badge = Label(
            text=str(number),
            font_size=dp(9),
            color=(0.15, 0.15, 0.15, 1),
            size_hint=(None, None),
            size=(cell_size * 0.5, cell_size * 0.4),
            pos=(cell.x, cell.y + cell_size * 0.55),
            halign="left",
            valign="top",
        )
        cell.number_label = badge

    def _make_on_press(self, r, c):
        def _on_press(*_):
            self.controller.on_cell_tapped(r, c)
        return _on_press

    def refresh_letters(self, user_grid):
        for (r, c), cell in self.cells.items():
            if not cell.blocked:
                cell.set_letter(user_grid.get((r, c), ""))


class ClueRow(ButtonBehavior, BoxLayout):
    def __init__(self, placed_word, controller, **kwargs):
        super().__init__(orientation="horizontal", size_hint_y=None, height=dp(34), **kwargs)
        self.placed_word = placed_word
        self.controller = controller
        label_text = f"{placed_word.number}. {placed_word.clue}"
        self.label = L(label_text, halign="right", valign="middle", font_size=dp(13))
        self.label.bind(size=self._update_text_size)
        self.add_widget(self.label)
        self.bind(on_release=self._select)

    def _update_text_size(self, *_):
        self.label.text_size = (self.label.width, None)

    def _select(self, *_):
        self.controller.select_word(self.placed_word)

    def set_highlight(self, active):
        self.label.color = (0.75, 0.35, 0.0, 1) if active else COLOR_INK


class CluesPanel(BoxLayout):
    def __init__(self, controller, **kwargs):
        super().__init__(orientation="vertical", **kwargs)
        self.controller = controller
        self.rows_by_word = {}

        header = BoxLayout(size_hint_y=None, height=dp(30))
        self.across_label = L("[b]أفقياً[/b]", markup=True, font_size=dp(14))
        self.down_label = L("[b]عمودياً[/b]", markup=True, font_size=dp(14))

        self.across_box = BoxLayout(orientation="vertical", size_hint_y=None)
        self.across_box.bind(minimum_height=self.across_box.setter("height"))
        self.down_box = BoxLayout(orientation="vertical", size_hint_y=None)
        self.down_box.bind(minimum_height=self.down_box.setter("height"))

        across_scroll = ScrollView()
        across_col = BoxLayout(orientation="vertical")
        across_col.add_widget(self.across_label)
        across_col.add_widget(self.across_box)
        across_scroll.add_widget(across_col)

        down_scroll = ScrollView()
        down_col = BoxLayout(orientation="vertical")
        down_col.add_widget(self.down_label)
        down_col.add_widget(self.down_box)
        down_scroll.add_widget(down_col)

        self.add_widget(across_scroll)
        self.add_widget(down_scroll)

    def build(self, puzzle: Puzzle):
        self.across_box.clear_widgets()
        self.down_box.clear_widgets()
        self.rows_by_word = {}
        for p in puzzle.across_words():
            row = ClueRow(p, self.controller)
            self.across_box.add_widget(row)
            self.rows_by_word[id(p)] = row
        for p in puzzle.down_words():
            row = ClueRow(p, self.controller)
            self.down_box.add_widget(row)
            self.rows_by_word[id(p)] = row

    def highlight_word(self, word):
        for key, row in self.rows_by_word.items():
            row.set_highlight(row.placed_word is word)


ARABIC_KEYS = [
    list("ضصثقفغعهخحج"),
    list("شسيبلاتنمكط"),
    list("ئءؤرلاىةوزظد"),
]


class Keyboard(GridLayout):
    def __init__(self, controller, **kwargs):
        super().__init__(cols=1, size_hint_y=None, spacing=dp(3), padding=dp(3), **kwargs)
        self.controller = controller
        for row_keys in ARABIC_KEYS:
            row = BoxLayout(size_hint_y=None, height=dp(38), spacing=dp(2))
            for ch in row_keys:
                btn = Button(text=ch, font_size=dp(16))
                if FONT_NAME:
                    btn.font_name = FONT_NAME
                btn.bind(on_release=lambda _b, c=ch: self.controller.input_letter(c))
                row.add_widget(btn)
            self.add_widget(row)
        action_row = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(4))
        back_btn = Button(text=ar("⌫ حذف"))
        back_btn.bind(on_release=lambda *_: self.controller.backspace())
        clear_btn = Button(text=ar("مسح الكل"))
        clear_btn.bind(on_release=lambda *_: self.controller.clear_word())
        reveal_btn = Button(text=ar("كشف حرف"))
        reveal_btn.bind(on_release=lambda *_: self.controller.reveal_letter())
        for w in (back_btn, clear_btn, reveal_btn):
            if FONT_NAME:
                w.font_name = FONT_NAME
            action_row.add_widget(w)
        self.add_widget(action_row)
        self.bind(minimum_height=self.setter("height"))


class CrosswordScreen(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", **kwargs)
        self.generator = CrosswordGenerator()
        self.store = ProgressStore(App.get_running_app().user_data_dir)

        self.puzzle: Puzzle = None
        self.user_grid = {}
        self.selected_word = None
        self.selected_cell = None
        self.completed_count = 0

        with self.canvas.before:
            Color(*COLOR_PAPER)
            self.bg_rect = Rectangle(pos=self.pos, size=self.size)
        self.bind(pos=self._update_bg, size=self._update_bg)

        self._build_ui()
        self._load_or_new_game()

    def _update_bg(self, *_):
        self.bg_rect.pos = self.pos
        self.bg_rect.size = self.size

    # ---------------------------------------------------------------- #
    def _build_ui(self):
        top_bar = BoxLayout(size_hint_y=None, height=dp(48), padding=dp(6), spacing=dp(6))
        self.title_label = L("[b]الكلمات المتقاطعة[/b]", markup=True, font_size=dp(18))
        self.stats_label = L("الألغاز المكتملة: 0", font_size=dp(12))
        new_game_btn = Button(text=ar("لغز جديد"), size_hint_x=None, width=dp(90))
        if FONT_NAME:
            new_game_btn.font_name = FONT_NAME
        new_game_btn.bind(on_release=lambda *_: self.confirm_new_game())
        top_bar.add_widget(new_game_btn)
        top_bar.add_widget(self.stats_label)
        top_bar.add_widget(self.title_label)
        self.add_widget(top_bar)

        self.clue_hint = L("", font_size=dp(14), size_hint_y=None, height=dp(30))
        self.add_widget(self.clue_hint)

        grid_scroll = ScrollView(size_hint_y=0.45)
        self.grid_widget = CrosswordGridWidget(controller=self, size_hint=(None, None))
        grid_container = BoxLayout(size_hint=(None, None))
        grid_container.add_widget(self.grid_widget)
        grid_container.bind(minimum_size=grid_container.setter("size"))
        grid_scroll.add_widget(grid_container)
        self.add_widget(grid_scroll)

        self.clues_panel = CluesPanel(controller=self, size_hint_y=0.30)
        self.add_widget(self.clues_panel)

        self.keyboard = Keyboard(controller=self, size_hint_y=None)
        self.add_widget(self.keyboard)

    # ---------------------------------------------------------------- #
    def _load_or_new_game(self):
        data = self.store.load()
        if data and data.get("puzzle"):
            try:
                self.puzzle = Puzzle.from_dict(data["puzzle"])
                self.user_grid = {
                    (int(k.split(",")[0]), int(k.split(",")[1])): v
                    for k, v in data.get("user_grid", {}).items()
                }
                self.completed_count = data.get("completed_count", 0)
                self._render_puzzle()
                return
            except Exception:
                pass
        self.new_puzzle(save=False)

    def new_puzzle(self, save=True):
        self.puzzle = self.generator.generate()
        self.user_grid = {}
        self.selected_word = None
        self.selected_cell = None
        self._render_puzzle()
        if save:
            self.save_progress()

    def confirm_new_game(self):
        popup_content = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(10))
        popup_content.add_widget(L("سيتم فقدان تقدمك في اللغز الحالي. متابعة؟", font_size=dp(14)))
        btn_row = BoxLayout(size_hint_y=None, height=dp(40), spacing=dp(8))
        popup = Popup(title=ar("لغز جديد"), content=popup_content, size_hint=(0.8, 0.35))
        yes_btn = Button(text=ar("نعم"))
        no_btn = Button(text=ar("إلغاء"))
        if FONT_NAME:
            yes_btn.font_name = FONT_NAME
            no_btn.font_name = FONT_NAME

        def do_yes(*_):
            popup.dismiss()
            self.new_puzzle()

        yes_btn.bind(on_release=do_yes)
        no_btn.bind(on_release=lambda *_: popup.dismiss())
        btn_row.add_widget(yes_btn)
        btn_row.add_widget(no_btn)
        popup_content.add_widget(btn_row)
        popup.open()

    def _render_puzzle(self):
        self.grid_widget.build(self.puzzle)
        self.grid_widget.refresh_letters(self.user_grid)
        self.clues_panel.build(self.puzzle)
        self.stats_label.text = ar(f"الألغاز المكتملة: {self.completed_count}")
        # اختر أول كلمة أفقية تلقائياً
        across = self.puzzle.across_words()
        if across:
            self.select_word(across[0])

    # ---------------------------------------------------------------- #
    def find_words_at(self, r, c):
        return [p for p in self.puzzle.placements if (r, c) in p.cells()]

    def on_cell_tapped(self, r, c):
        words_here = self.find_words_at(r, c)
        if not words_here:
            return
        if self.selected_word in words_here and len(words_here) > 1:
            # اضغط مرة أخرى على خانة تقاطع للتبديل بين الاتجاهين
            other = [w for w in words_here if w is not self.selected_word][0]
            self.select_word(other, cell=(r, c))
        else:
            preferred = next((w for w in words_here if w.direction == "H"), words_here[0])
            self.select_word(preferred, cell=(r, c))

    def select_word(self, word, cell=None):
        self.selected_word = word
        self.selected_cell = cell or (word.row, word.col)
        self._refresh_highlight()
        self.clues_panel.highlight_word(word)
        direction_txt = "أفقياً" if word.direction == "H" else "عمودياً"
        self.clue_hint.text = ar(f"{word.number} {direction_txt}: {word.clue}")

    def _refresh_highlight(self):
        for cell in self.grid_widget.cells.values():
            if not cell.blocked:
                cell.reset_highlight()
        if not self.selected_word:
            return
        for coord in self.selected_word.cells():
            cell = self.grid_widget.cells.get(coord)
            if cell:
                cell.set_highlight(COLOR_SELECTED_WORD)
        if self.selected_cell:
            cell = self.grid_widget.cells.get(self.selected_cell)
            if cell:
                cell.set_highlight(COLOR_SELECTED_CELL)

    # ---------------------------------------------------------------- #
    def _advance_cursor(self):
        word = self.selected_word
        if not word:
            return
        cells = word.cells()
        idx = cells.index(self.selected_cell) if self.selected_cell in cells else -1
        if idx + 1 < len(cells):
            self.selected_cell = cells[idx + 1]
        self._refresh_highlight()

    def _retreat_cursor(self):
        word = self.selected_word
        if not word:
            return
        cells = word.cells()
        idx = cells.index(self.selected_cell) if self.selected_cell in cells else 0
        if idx - 1 >= 0:
            self.selected_cell = cells[idx - 1]
        self._refresh_highlight()

    def input_letter(self, letter):
        if not self.selected_cell or not self.puzzle.is_open(*self.selected_cell):
            return
        letter = normalize_char(letter)
        self.user_grid[self.selected_cell] = letter
        self.grid_widget.cells[self.selected_cell].set_letter(letter)
        self._advance_cursor()
        self.save_progress()
        self._check_completion()

    def backspace(self):
        if not self.selected_cell:
            return
        if self.user_grid.get(self.selected_cell):
            self.user_grid[self.selected_cell] = ""
            self.grid_widget.cells[self.selected_cell].set_letter("")
        else:
            self._retreat_cursor()
            if self.selected_cell in self.user_grid:
                self.user_grid[self.selected_cell] = ""
                self.grid_widget.cells[self.selected_cell].set_letter("")
        self.save_progress()

    def clear_word(self):
        if not self.selected_word:
            return
        for coord in self.selected_word.cells():
            self.user_grid[coord] = ""
            self.grid_widget.cells[coord].set_letter("")
        self.save_progress()

    def reveal_letter(self):
        if not self.selected_cell:
            return
        correct = self.puzzle.solution.get(self.selected_cell)
        if correct:
            self.user_grid[self.selected_cell] = correct
            self.grid_widget.cells[self.selected_cell].set_letter(correct)
            self.save_progress()
            self._check_completion()

    # ---------------------------------------------------------------- #
    def _check_completion(self):
        for coord, correct_letter in self.puzzle.solution.items():
            if self.user_grid.get(coord) != correct_letter:
                return
        self.completed_count += 1
        self.stats_label.text = ar(f"الألغاز المكتملة: {self.completed_count}")
        self.save_progress()
        self._show_success_popup()

    def _show_success_popup(self):
        content = BoxLayout(orientation="vertical", spacing=dp(10), padding=dp(12))
        content.add_widget(L(f"أحسنت! أكملت اللغز رقم {self.completed_count} 🎉", font_size=dp(16)))
        btn = Button(text=ar("لغز جديد"), size_hint_y=None, height=dp(42))
        if FONT_NAME:
            btn.font_name = FONT_NAME
        popup = Popup(title=ar("تهانينا"), content=content, size_hint=(0.85, 0.4), auto_dismiss=False)

        def go_next(*_):
            popup.dismiss()
            self.new_puzzle()

        btn.bind(on_release=go_next)
        content.add_widget(btn)
        popup.open()
        Clock.schedule_once(lambda *_: go_next() if popup.parent else None, 3.5)

    # ---------------------------------------------------------------- #
    def save_progress(self):
        data = {
            "puzzle": self.puzzle.to_dict(),
            "user_grid": {f"{r},{c}": v for (r, c), v in self.user_grid.items() if v},
            "completed_count": self.completed_count,
        }
        self.store.save(data)


class CrosswordApp(App):
    def build(self):
        self.title = "الكلمات المتقاطعة"
        Window.clearcolor = COLOR_PAPER
        self.screen = CrosswordScreen()
        return self.screen

    def on_pause(self):
        # يُستدعى عند انتقال التطبيق للخلفية في أندرويد؛ نحفظ التقدم فوراً
        self.screen.save_progress()
        return True

    def on_stop(self):
        self.screen.save_progress()

    def on_resume(self):
        pass


if __name__ == "__main__":
    CrosswordApp().run()
