[app]
title = الكلمات المتقاطعة
package.name = crosswordar
package.domain = org.example

source.dir = .
source.include_exts = py,ttf,json,png,jpg,kv
version = 1.0

requirements = python3,kivy==2.3.0,arabic_reshaper,python-bidi

orientation = portrait
fullscreen = 0

icon.filename = %(source.dir)s/assets/icon.png
presplash.filename = %(source.dir)s/assets/presplash.png

android.permissions = 
android.api = 34
android.minapi = 21
android.ndk = 25b
android.archs = arm64-v8a,armeabi-v7a
android.allow_backup = True

[buildozer]
log_level = 2
warn_on_root = 1
