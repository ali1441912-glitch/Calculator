# -*- coding: utf-8 -*-
"""
أدوات مساعدة للنصوص العربية:
1) normalize_word: لتوحيد أشكال الألف والياء والتشكيل حتى تتطابق الحروف
   عند بناء شبكة الكلمات المتقاطعة وأثناء إدخال المستخدم.
2) ar: لإعادة تشكيل النص العربي وضبط اتجاهه (RTL) قبل عرضه داخل Kivy،
   لأن Kivy لا يدعم تشكيل الحروف العربية بشكل تلقائي.
"""

import re

_TASHKEEL_RE = re.compile(r"[\u064B-\u0652\u0670\u0640]")  # تشكيل وتطويل

_CHAR_MAP = {
    "أ": "ا",
    "إ": "ا",
    "آ": "ا",
    "ى": "ي",
    "ؤ": "و",
    "ئ": "ي",
}


def normalize_word(text: str) -> str:
    """توحيد الحروف المتشابهة وإزالة الفراغات والتشكيل، لأغراض المطابقة في الشبكة."""
    if not text:
        return ""
    text = _TASHKEEL_RE.sub("", text)
    text = text.replace(" ", "")
    return "".join(_CHAR_MAP.get(ch, ch) for ch in text)


def normalize_char(ch: str) -> str:
    if not ch:
        return ch
    return _CHAR_MAP.get(ch, ch)


# --- عرض النص العربي بشكل صحيح داخل Kivy ---
try:
    import arabic_reshaper
    from bidi.algorithm import get_display

    _RESHAPER_AVAILABLE = True
except Exception:  # المكتبتان قد لا تكونان مثبتتين أثناء التطوير على سطح المكتب
    _RESHAPER_AVAILABLE = False


def ar(text: str) -> str:
    """
    يعيد تشكيل النص العربي (ربط الحروف) ويهيئه للعرض من اليمين لليسار.
    استخدم هذه الدالة لأي عنوان أو نص متعدد الأحرف يُعرض في تسميات Kivy.
    لا تستخدمها لحرف مفرد داخل خانة الشبكة (الحرف المفرد لا يحتاج تشكيلاً).
    """
    if not text:
        return text
    if not _RESHAPER_AVAILABLE:
        return text
    reshaped = arabic_reshaper.reshape(text)
    return get_display(reshaped)
