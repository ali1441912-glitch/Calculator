# -*- coding: utf-8 -*-
"""
مولّد الكلمات المتقاطعة.
يبني شبكة بأسلوب هيكل الكلمات المتقاطعة الكلاسيكي (Skeleton Crossword):
يضع كلمات تتقاطع في حروف مشتركة، ثم يحوّل باقي الخانات إلى خانات سوداء مغلقة.
مصمم ليولّد لغزاً جديداً في كل مرة (عشوائي)، مما يحقق خاصية "بلا نهاية".
"""

import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from arabic_utils import normalize_word
from word_bank import WORD_BANK

Coord = Tuple[int, int]


@dataclass
class PlacedWord:
    answer: str          # الكلمة بعد التطبيع (تُستخدم للمطابقة والتعبئة)
    clue: str
    row: int
    col: int
    direction: str        # 'H' أو 'V'
    number: int = 0

    def cells(self) -> List[Coord]:
        dr, dc = (0, 1) if self.direction == "H" else (1, 0)
        return [(self.row + dr * i, self.col + dc * i) for i in range(len(self.answer))]


@dataclass
class Puzzle:
    width: int
    height: int
    placements: List[PlacedWord]
    solution: Dict[Coord, str]      # الحل الصحيح لكل خانة مفتوحة
    numbering: Dict[Coord, int]     # رقم الخانة إن كانت بداية كلمة (أفقية أو عمودية)

    def is_open(self, r: int, c: int) -> bool:
        return (r, c) in self.solution

    def across_words(self) -> List[PlacedWord]:
        return sorted([p for p in self.placements if p.direction == "H"], key=lambda p: p.number)

    def down_words(self) -> List[PlacedWord]:
        return sorted([p for p in self.placements if p.direction == "V"], key=lambda p: p.number)

    def to_dict(self) -> dict:
        return {
            "width": self.width,
            "height": self.height,
            "placements": [
                {
                    "answer": p.answer,
                    "clue": p.clue,
                    "row": p.row,
                    "col": p.col,
                    "direction": p.direction,
                    "number": p.number,
                }
                for p in self.placements
            ],
            "solution": {f"{r},{c}": ch for (r, c), ch in self.solution.items()},
            "numbering": {f"{r},{c}": n for (r, c), n in self.numbering.items()},
        }

    @staticmethod
    def from_dict(data: dict) -> "Puzzle":
        placements = [
            PlacedWord(
                answer=p["answer"],
                clue=p["clue"],
                row=p["row"],
                col=p["col"],
                direction=p["direction"],
                number=p["number"],
            )
            for p in data["placements"]
        ]
        solution = {}
        for key, ch in data["solution"].items():
            r, c = key.split(",")
            solution[(int(r), int(c))] = ch
        numbering = {}
        for key, n in data["numbering"].items():
            r, c = key.split(",")
            numbering[(int(r), int(c))] = n
        return Puzzle(
            width=data["width"],
            height=data["height"],
            placements=placements,
            solution=solution,
            numbering=numbering,
        )


class CrosswordGenerator:
    def __init__(self, max_dim: int = 15, target_words: int = 16, min_words: int = 9):
        self.max_dim = max_dim
        self.target_words = target_words
        self.min_words = min_words
        # نطبّع كل كلمات البنك مرة واحدة
        self.pool = [{"answer": normalize_word(w["answer"]), "clue": w["clue"]} for w in WORD_BANK]

    # ------------------------------------------------------------------ #
    def generate(self, tries: int = 40, rng: Optional[random.Random] = None) -> Puzzle:
        rng = rng or random.Random()
        best_result = None
        for _ in range(tries):
            result = self._attempt(rng)
            if result and len(result[0]) >= self.min_words:
                # نجاح كافٍ، لكن نحاول اختيار أفضل محاولة (أكثر كلمات) بين عدة محاولات قليلة
                if best_result is None or len(result[0]) > len(best_result[0]):
                    best_result = result
                if len(result[0]) >= self.target_words:
                    break
        if best_result is None:
            # كحل أخير خفف الشروط
            for _ in range(tries):
                result = self._attempt(rng, min_words_override=4)
                if result:
                    best_result = result
                    break
        if best_result is None:
            raise RuntimeError("تعذر توليد لغز كلمات متقاطعة، تحقق من بنك الكلمات")

        placements, letter_grid = best_result
        return self._finalize(placements, letter_grid)

    # ------------------------------------------------------------------ #
    def _attempt(self, rng: random.Random, min_words_override: Optional[int] = None):
        words = list(self.pool)
        rng.shuffle(words)
        # نفضل الكلمات الأطول أولاً مع بعض العشوائية بينها
        words.sort(key=lambda w: len(w["answer"]) + rng.random() * 2, reverse=True)

        letter_grid: Dict[Coord, str] = {}
        passes: Dict[Coord, set] = {}
        placements: List[PlacedWord] = []
        used_answers = set()

        def bounds_ok(cells: List[Coord]) -> bool:
            rows = [r for r, c in cells]
            cols = [c for r, c in cells]
            all_rows = rows + [p.row for p in placements for _ in [0]]
            # نحسب الحدود بافتراض إضافة هذه الخانات لما هو موجود
            min_r = min(rows + [pc[0] for pc in letter_grid.keys()], default=0)
            max_r = max(rows + [pc[0] for pc in letter_grid.keys()], default=0)
            min_c = min(cols + [pc[1] for pc in letter_grid.keys()], default=0)
            max_c = max(cols + [pc[1] for pc in letter_grid.keys()], default=0)
            return (max_r - min_r + 1) <= self.max_dim and (max_c - min_c + 1) <= self.max_dim

        def can_place(answer: str, r: int, c: int, direction: str) -> bool:
            dr, dc = (0, 1) if direction == "H" else (1, 0)
            cells = [(r + dr * i, c + dc * i) for i in range(len(answer))]
            # تحقق من الخانة قبل البداية وبعد النهاية (يجب أن تكون فارغة لعدم دمج كلمات)
            before = (r - dr, c - dc)
            after = (r + dr * len(answer), c + dc * len(answer))
            if before in letter_grid or after in letter_grid:
                return False
            has_intersection = False
            for i, (rr, cc) in enumerate(cells):
                ch = answer[i]
                if (rr, cc) in letter_grid:
                    if letter_grid[(rr, cc)] != ch:
                        return False
                    if direction in passes.get((rr, cc), set()):
                        return False
                    has_intersection = True
                else:
                    # الخانة فارغة: يجب ألا يكون لها جيران متعامدون (لمنع التصاق كلمات بلا تقاطع فعلي)
                    if direction == "H":
                        n1, n2 = (rr - 1, cc), (rr + 1, cc)
                    else:
                        n1, n2 = (rr, cc - 1), (rr, cc + 1)
                    if n1 in letter_grid or n2 in letter_grid:
                        return False
            if not has_intersection and placements:
                return False
            if not bounds_ok(cells):
                return False
            return True

        def place(answer: str, clue: str, r: int, c: int, direction: str):
            dr, dc = (0, 1) if direction == "H" else (1, 0)
            for i, ch in enumerate(answer):
                rr, cc = r + dr * i, c + dc * i
                letter_grid[(rr, cc)] = ch
                passes.setdefault((rr, cc), set()).add(direction)
            placements.append(PlacedWord(answer=answer, clue=clue, row=r, col=c, direction=direction))

        # الكلمة الأولى فى المنتصف تقريبًا (أفقيًا)
        first = words[0]
        place(first["answer"], first["clue"], 0, 0, "H")
        used_answers.add(first["answer"])

        for w in words[1:]:
            if len(placements) >= self.target_words:
                break
            answer, clue = w["answer"], w["clue"]
            if answer in used_answers or len(answer) < 3:
                continue
            candidates = []
            for i, ch in enumerate(answer):
                for (rr, cc), gch in list(letter_grid.items()):
                    if gch != ch:
                        continue
                    # جرّب اتجاهين متعامدين مع الاتجاه الموجود بالفعل في تلك الخانة
                    for direction in ("H", "V"):
                        r0 = rr - (i if direction == "V" else 0)
                        c0 = cc - (i if direction == "H" else 0)
                        if can_place(answer, r0, c0, direction):
                            candidates.append((r0, c0, direction))
            if not candidates:
                continue
            r0, c0, direction = rng.choice(candidates)
            place(answer, clue, r0, c0, direction)
            used_answers.add(answer)

        min_words = min_words_override or self.min_words
        if len(placements) < min_words:
            return None
        return placements, letter_grid

    # ------------------------------------------------------------------ #
    def _finalize(self, placements: List[PlacedWord], letter_grid: Dict[Coord, str]) -> Puzzle:
        rows = [r for r, c in letter_grid.keys()]
        cols = [c for r, c in letter_grid.keys()]
        min_r, max_r = min(rows), max(rows)
        min_c, max_c = min(cols), max(cols)

        # إزاحة الإحداثيات لتبدأ من الصفر
        shifted_solution = {}
        for (r, c), ch in letter_grid.items():
            shifted_solution[(r - min_r, c - min_c)] = ch

        shifted_placements = []
        for p in placements:
            shifted_placements.append(
                PlacedWord(
                    answer=p.answer,
                    clue=p.clue,
                    row=p.row - min_r,
                    col=p.col - min_c,
                    direction=p.direction,
                )
            )

        width = max_c - min_c + 1
        height = max_r - min_r + 1

        # ترقيم الخانات وفق قاعدة الكلمات المتقاطعة الكلاسيكية
        starts_across = {(p.row, p.col) for p in shifted_placements if p.direction == "H"}
        starts_down = {(p.row, p.col) for p in shifted_placements if p.direction == "V"}
        numbering: Dict[Coord, int] = {}
        counter = 1
        for r in range(height):
            for c in range(width):
                if (r, c) in starts_across or (r, c) in starts_down:
                    numbering[(r, c)] = counter
                    counter += 1

        for p in shifted_placements:
            p.number = numbering[(p.row, p.col)]

        return Puzzle(
            width=width,
            height=height,
            placements=shifted_placements,
            solution=shifted_solution,
            numbering=numbering,
        )


if __name__ == "__main__":
    gen = CrosswordGenerator()
    puzzle = gen.generate()
    print(f"الحجم: {puzzle.width} × {puzzle.height} | عدد الكلمات: {len(puzzle.placements)}")
    grid_display = [["." for _ in range(puzzle.width)] for _ in range(puzzle.height)]
    for (r, c), ch in puzzle.solution.items():
        grid_display[r][c] = ch
    for row in grid_display:
        print(" ".join(row))
    print("\nأفقي:")
    for p in puzzle.across_words():
        print(f"{p.number}. {p.clue}  ({len(p.answer)} أحرف)")
    print("\nعمودي:")
    for p in puzzle.down_words():
        print(f"{p.number}. {p.clue}  ({len(p.answer)} أحرف)")
