# -*- coding: utf-8 -*-
"""
حفظ واستعادة تقدم اللاعب.
يُحفظ ملف JSON واحد يحتوي: اللغز الحالي، حروف المستخدم المدخلة حتى الآن،
وعدد الألغاز المُنجزة (لعرضها كإحصائية للمستخدم).
"""

import json
import os


class ProgressStore:
    def __init__(self, base_dir: str):
        os.makedirs(base_dir, exist_ok=True)
        self.path = os.path.join(base_dir, "crossword_progress.json")

    def load(self):
        if not os.path.exists(self.path):
            return None
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return None

    def save(self, data: dict):
        tmp_path = self.path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp_path, self.path)

    def clear(self):
        if os.path.exists(self.path):
            os.remove(self.path)
